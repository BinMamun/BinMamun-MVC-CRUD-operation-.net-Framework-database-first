﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Work_1264603.Models.Metadata
{
    public class BreedType
    {
        public int BreedId { get; set; }

        [Required, StringLength(50), Display(Name = "Breed")]
        public string BreedName { get; set; }

        [Required, Display(Name = "Average Age(Years)")]
        public int Average_Age { get; set; }
        [Required]
        public string Description { get; set; }
    }

    public partial class CatType
    {
        public int CatId { get; set; }

        [Required, StringLength(50), Display(Name = "Cat Name")]
        public string CatName { get; set; }

        [Required, DataType(DataType.Date), Display(Name = "Date Of Birth"),
            DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public System.DateTime DOB { get; set; }

        [Required, StringLength(30)]
        public string Gender { get; set; }

        [Required, StringLength(150)]
        public string Picture { get; set; }
        [Required]
        public int BreedId { get; set; }

    }
}