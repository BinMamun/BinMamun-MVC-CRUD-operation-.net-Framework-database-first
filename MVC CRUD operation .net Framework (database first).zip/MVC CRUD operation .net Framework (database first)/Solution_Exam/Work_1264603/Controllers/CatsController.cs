﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Work_1264603.Models;
using Work_1264603.ViewModels;

namespace Work_1264603.Controllers
{
    public class CatsController : Controller
    {
        private readonly CatsDbContext db = new CatsDbContext();

        // GET: Cats
        public ActionResult Index(int page = 1)
        {
            ViewBag.CurrentPage = page;
            ViewBag.TotalPage = (int)Math.Ceiling((double)db.Cats.Count() / 5);

            var data = db.Cats
                .OrderBy(x => x.CatId)
                .Skip((page - 1) * 5)
                .Take(5)
                .ToList();

            return View(data);
        }

        public ActionResult Create()
        {
            ViewBag.GenderOption = new string[] { "Male", "Female" };
            ViewBag.Breeds = db.Breeds.ToList();
            return View();
        }

        [HttpPost]

        public ActionResult Create(CatViewModel c)
        {
            Cat cat = new Cat { CatName = c.CatName, Gender = c.Gender, DOB = c.DOB, BreedId = c.BreedId, Picture = "1.jpg" };

            if (ModelState.IsValid)
            {
                if (c.Picture != null)
                {
                    string fileName = Guid.NewGuid() + Path.GetExtension(c.Picture.FileName);
                    c.Picture.SaveAs(Server.MapPath("~/Uploads/") + fileName);
                    cat.Picture = fileName;
                }
                db.Cats.Add(cat);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.GenderOption = new string[] { "Male", "Female" };
            ViewBag.Breeds = db.Breeds.ToList();
            return View(c);

        }

        public ActionResult Edit(int id)
        {
            var c = db.Cats.First(x => x.CatId == id);

            ViewBag.Breeds = db.Breeds.ToList();
            ViewBag.GenderOption = new string[] { "Male", "Female" };
            ViewBag.Pic = c.Picture;

            return View(new CatViewModel { CatId = c.CatId, CatName = c.CatName, Gender = c.Gender, DOB = c.DOB, BreedId = c.BreedId, });

        }

        [HttpPost]
        public ActionResult Edit(CatViewModel c)
        {
            var edit = db.Cats.First(x => x.CatId == c.CatId);

            edit.CatName = c.CatName;
            edit.Gender = c.Gender;
            edit.DOB = c.DOB;
            edit.BreedId = c.BreedId;
            edit.Breed = c.Breed;

            if (ModelState.IsValid)
            {
                if (c.Picture != null)
                {
                    string fileName = Guid.NewGuid() + Path.GetExtension(c.Picture.FileName);
                    c.Picture.SaveAs(Server.MapPath("~/Uploads/") + fileName);
                    edit.Picture = fileName;
                }


                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Breeds = db.Breeds.ToList();
            ViewBag.GenderOption = new string[] { "Male", "Female" };
            ViewBag.Pic = edit.Picture;
            return View(c);
        }

        public ActionResult Delete(int id)
        {
            var c = db.Cats.First(x => x.CatId == id);
            ViewBag.Pic = c.Picture;
            return View(c);
        }

        [HttpPost, ActionName("Delete")]

        public ActionResult DeleteConfirm(int id)
        {
            Cat c = new Cat { CatId = id };
            ViewBag.Pic = c.Picture;

            db.Entry(c).State = System.Data.Entity.EntityState.Deleted;
            db.SaveChanges();
            return RedirectToAction("Index");
        }



    }
}