﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Work_1264603.Models;

namespace Work_1264603.Controllers
{
    public class BreedsController : Controller
    {
        readonly CatsDbContext db = new CatsDbContext();
        // GET: Breeds
        public ActionResult Index()
        {
            return View(db.Breeds.ToList());
        }

        public PartialViewResult BreedsList()
        {
            return PartialView("_BreedsPartial", db.Breeds.ToList());
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Breed b)
        {
            if (ModelState.IsValid)
            {
                db.Breeds.Add(b);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(b);
        }


        public ActionResult Edit(int id)
        {
            return View(db.Breeds.First(x => x.BreedId == id));

        }

        [HttpPost]

        public ActionResult Edit(Breed b)
        {
            if (ModelState.IsValid)
            {
                db.Entry(b).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(b);
        }

        public ActionResult Delete(int id)
        {
            return View(db.Breeds.First(x => x.BreedId == id));
        }


        [HttpPost, ActionName("Delete")]
        public ActionResult ConfirmDelete(int id)
        {
            Breed b = new Breed { BreedId = id };
            db.Entry(b).State = System.Data.Entity.EntityState.Deleted;
            db.SaveChanges();
            return RedirectToAction("Index");

        }
    }
}